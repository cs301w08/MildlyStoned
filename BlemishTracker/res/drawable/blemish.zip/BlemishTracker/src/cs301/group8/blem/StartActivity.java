package cs301.group8.blem;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;



public class StartActivity extends Activity {
    /** Called when the activity is first created. */
    private SharedPreferences mPreferences;
    public static final String PREFS_NAME = "MyPrefsFile";
  //  public static final String PREFS_NAME = "MyPrefsFile";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verify);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        boolean first = settings.getBoolean("first", false);
        if(first){
            Intent intent2 = new Intent();
            intent2.setClass(StartActivity.this,VerifyActivity.class);
            StartActivity.this.startActivity(intent2);
        }else{
            Intent intent2 = new Intent();
            intent2.setClass(StartActivity.this,BlemishTabActivity.class);
            StartActivity.this.startActivity(intent2);
        }
    }
}