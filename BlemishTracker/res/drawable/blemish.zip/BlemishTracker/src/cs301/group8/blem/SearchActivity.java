package cs301.group8.blem;

import java.util.ArrayList;

import cs301.group8.database.AppDatabase;
import cs301.group8.meta.Picture;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;



public class SearchActivity extends ListActivity
{
    private final int DIALOG_ADDGROUP = 0;
    private Dialog dialog = null;
    private AppDatabase db;
    private Button search;
    private EditText searchbar;
    protected ArrayList<String> groups;
    protected ArrayList<Picture> pics;
    private CustomAdapter listAdpt;
    private int pos;
    /** onCreate is called when the activity is created in the application.  onCreate sets the listener for the 
     * add blemish button.
     */
    public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.search);

            android.util.Log.i("VERRIFY", "working");
            searchbar=(EditText)findViewById(R.id.editText1);
            search=(Button)findViewById(R.id.button1);
            search.setOnClickListener(new searchListener());
    }
    
    
    /** onStart is called when the activity starts for the user. onStart creates the PictureDatabase object and 
     * pulls any existing groups from the database.  It fills an array of groups using the getGroups database method and sets 
     * the ListView adapter to this array
     */
    protected void onStart(){
            super.onStart();
            db = new AppDatabase(this);
            groups = db.getGroups();
            listAdpt = new CustomAdapter(this, R.layout.group_item);
            this.getListView().setAdapter(listAdpt); 
    }
    protected void onDestroy(){
            super.onDestroy();
            db.close();
    }

    @Override
    protected void onResume (){
            android.util.Log.i("VERRIFY", "onResume");
            super.onResume();
            update();
    }
    private void update(){
            if (listAdpt != null){
                    groups = db.getGroups();
                    listAdpt.clear();
                    for (int i=0;i<groups.size();i++){
                            listAdpt.add(groups.get(i));
                            android.util.Log.i("VERRIFY", "Added to ListAdpt " + i);
                    }
            }
            listAdpt.notifyDataSetChanged();

    }
    public class searchListener implements OnClickListener{

        @Override
        public void onClick(View v)
        {
          
                String value = searchbar.getText().toString();
                if (value.equals("") || value == null){
                        //user enters an empty string
                        removeDialog(Dialogs.DIALOG_ADD_GROUP);
                        Toast.makeText(getApplicationContext(), "Error: Cannot search a picture with an empty name.",
                                        Toast.LENGTH_SHORT).show();
                        Log.i("DATA", "Error: Cannot add empty string group");
                } else {
                        //value has something significant
                   String[] separate=value.split("\\:");
                   if(separate[0].equals("DateBefore")){
                       long date=Long.valueOf(separate[1]);
                       pics=db.getPicturesbefore(date);
                       for(int i = 0;i<pics.size();i++){
                           System.out.println(pics.get(i).getTime());
                    
                       }
                       
                   }
                   if(separate[0].equals("DateAfter")){
                       Toast t = Toast.makeText(getApplicationContext(), "U wanna search date after", Toast.LENGTH_SHORT);
                       t.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 85);
                       t.show();
                   }
                   if(separate[0].equals("Tag")){
                       Toast t = Toast.makeText(getApplicationContext(), "U wanna search by tag", Toast.LENGTH_SHORT);
                       t.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 85);
                       t.show();
                   }
                   if(separate[0].equals("Note")){
                       Toast t = Toast.makeText(getApplicationContext(), "U wanna search by note", Toast.LENGTH_SHORT);
                       t.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 85);
                       t.show();
                   }   
                   
                }
        
     
        }
    }
    protected void onListItemClick(ListView l, View v,int position, long id){
            android.util.Log.i("VERRIFY", "Clicked item: " + position + " String " + groups.get(position));
            super.onListItemClick(l, v, position, id);

            Intent intent = new Intent(getApplicationContext(), BlemishActivity.class);
            intent.putExtra("groupName", groups.get(position));
            startActivity(intent);
    }

    /** onCreateDialog is executed when MainActivity is first started.  This method initiates the two 
     * dialogs for this class by calling the makeDialog method for both types ('add group' and 'delete item').
     * onCreateDialog returns the dialog object to the activity.
     * 
     * @param id                    integer value corresponding to the identification number of each unique dialog
     * 
     * @return dialog               dialog object returned to the activity
     */
    @Override
    protected Dialog onCreateDialog(int id){
            Dialog dialog = null;
            switch (id) {
            case Dialogs.DIALOG_ADD_GROUP:
                    //dialog = Dialogs.makeAddGroupDialog(this, this, this);
                    this.dialog = dialog;
                    break;
            case Dialogs.DIALOG_DELETE_ITEM:
                    final int position = pos;
                    dialog = Dialogs.makeDeleteDialog(this, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                    db.deleteGroup(groups.get(position));
                                    update();
                                    removeDialog(Dialogs.DIALOG_DELETE_ITEM);
                            }
                    }, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                    removeDialog(Dialogs.DIALOG_DELETE_ITEM);
                            }
                    });
            default:
                    break;
            }
            return dialog;

    }
    /** onClick is called when the user presses the Add Blemish button.  onClick initiates the 'add blemish' dialog
     * and draws user input from the EditText regarding the group name that is desired by the user.  If the group name
     * already exists, onClick produces a toast to inform the user that the group name cannot be duplicated.  Otherwise,
     * onClick adds the group to the database with the addGroup method and starts an intent to transfer to BlemishActivity.
     *
     * @param v             The view element that was clicked on by the user (Add Blemish button in this case)
     */
    public void onClick(View v) {
            switch (v.getId()) {
            case R.id.dialog_add_blemish:
                    if (this.dialog != null){
                            String value = ((EditText) dialog.findViewById(R.id.BlemishGroup)).getText().toString();
                            if (value.equals("") || value == null){
                                    //user enters an empty string
                                    removeDialog(Dialogs.DIALOG_ADD_GROUP);
                                    Toast.makeText(getApplicationContext(), "Error: Cannot search a group with an empty name.",
                                                    Toast.LENGTH_SHORT).show();
                                    Log.i("DATA", "Error: Cannot add empty string group");
                            } else {
                                    //value has something significant
                               String[] date=value.split("\\|");
                               System.out.println(date[0]);
                            }
                    }
                    break;
            case R.id.dialog_no_blemish:
                    removeDialog(Dialogs.DIALOG_ADD_GROUP);
                    break;
            default:
                    break;
            }
    }

    private class CustomAdapter extends ArrayAdapter<String>{

            public CustomAdapter (Context context, int res_id){
                    super (context, res_id, groups);
                    android.util.Log.i("VERRIFY", "Custom Created");
            }

            /** getView is called for each element in the list.  It allows for us to place a button (the X delete button) inside
             * each ListView item based on the layout file.  getView returns 'row', the custom view used to populate the ListView
             *
             * @param position              position of the element in the ListView
             * @param convertView           
             * @param parent                parent viewgroup that is passed to the inflater
             *
             * @return row                  row is the custom view used to populate the ListView in the MainActivity
             */
            @Override
            public View getView(final int position, View convertView, ViewGroup parent){
                    if (groups == null){
                            return convertView;
                    }

                    LayoutInflater inflater=getLayoutInflater();
                    View row=inflater.inflate(R.layout.group_item, parent, false);
                    ((Button) row.findViewById(R.id.group_remove_button)).setOnClickListener(new OnClickListener() {
                            /** onClick is called when the user presses the X button for a particular group. onClick shows the 
                             * 'delete item' dialog which prompts the user to confirm if they want to delete the group or not.
                             *
                             * @param v             The view element that was clicked on by the user (X button in this case)
                             */
                            public void onClick(View v) {
                                    pos = position;
                                    showDialog(Dialogs.DIALOG_DELETE_ITEM);
                            }
                    });

                    TextView label=(TextView)row.findViewById(R.id.title_text);
                    String group = groups.get(position);
                    String format = "%3d pics%12s%-20s";
                    label.setText(String.format(format, db.getPicCount(group),"", group));
                    return row;
            }
    }
}