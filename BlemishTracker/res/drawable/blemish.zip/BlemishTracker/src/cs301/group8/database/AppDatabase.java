package cs301.group8.database;

import java.util.ArrayList;

import cs301.group8.meta.Picture;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;
import android.util.Log;

import static cs301.group8.database.Constants.*;

/** PictureDatabase uses SQLite database to create a table where we store our picture 
 * information.  This class provides a variety of methods which allow the application 
 * to create, add to, delete, and modify elements corresponding to different pictures.
 * Each row in the database table represents a unique image.  The table contains 4 
 * columns to describe each picture: group, path, note associated with the photo,
 * and time that the picture was taken.
 *
 * @author Group 08 <cs301-group8@ualberta.ca>
 * @version 1.0
 */
public class AppDatabase {

	private Context context;

	SQLiteDatabase db;
	DatabaseHelper dbHelper;
	
	

	/** PictureDatabase constructor uses the current context of the application (to avoid 
	 * duplicating or losing data) to create the database object.
	 *
	 * @param ctx		context of the Android application
	 */
	public AppDatabase(Context ctx){
		context = ctx;
		Log.i("database", "Constructor called");
		dbHelper = new DatabaseHelper(context,DATABASE_NAME);   
		db = dbHelper.getReadableDatabase();
		


	}
	/** getGroups queries the database and uses the database cursor to return an array 
	 * of strings which corresponds to all existing names of groups.
	 *
	 * @return groups	Array of strings representing the existing groups
	 */
	public ArrayList<String> getGroups(){//get groupnames with condition time!=0
		ArrayList<String> groups = new ArrayList<String>();
		Cursor cursor= db.rawQuery("SELECT DISTINCT " + COL_GROUP  + " FROM " + GROUPTABLE, null);
		int group_i = cursor.getColumnIndex(COL_GROUP);
		while(cursor.moveToNext()){
			groups.add(cursor.getString(group_i));
		}  
		cursor.close();
		return groups;
	}

	/** getPictures queries the database and uses the database cursor to return an array 
	 * of picture objects which consists of all pictures that have been added so far
	 * that match the group name parameter.
	 *
	 * @param groupName	String of the group name of the specific blemish
	 *
	 * @return groups	Array of strings representing the existing groups
	 */
	public ArrayList<Picture> getPictures(String groupName){ //get pictures get all picture based on group name

		ArrayList<Picture> pics = new ArrayList<Picture>();
		Cursor cursor = db.rawQuery("SELECT * FROM " + PICTURETABLE + " WHERE " + COL_GROUP + "=?",  new String[]{groupName});

		int group_i = cursor.getColumnIndex(COL_GROUP), time_i = cursor.getColumnIndex(COL_TIME), path_i = cursor.getColumnIndex(COL_PATH), note_i=cursor.getColumnIndex(COL_NOTE);
		while(cursor.moveToNext()){
			if(cursor.getLong(time_i)!=0){
				Picture pic = (new Picture(cursor.getString(group_i),cursor.getLong(time_i), cursor.getString(path_i)));
				pic.setNote(cursor.getString(note_i));
				pics.add(pic);
			}
		}  
		cursor.close();
		return pics;
	}

        public ArrayList<Picture> getPicturesbefore(long date){ //get pictures get all picture based on group name

            ArrayList<Picture> pics = new ArrayList<Picture>();
            Cursor cursor = db.rawQuery("SELECT * FROM " + PICTURETABLE + " WHERE " + COL_TIME + "<" + date, null);

            int group_i = cursor.getColumnIndex(COL_GROUP), time_i = cursor.getColumnIndex(COL_TIME), path_i = cursor.getColumnIndex(COL_PATH), note_i=cursor.getColumnIndex(COL_NOTE);
            while(cursor.moveToNext()){
                    if(cursor.getLong(time_i)!=0){
                            Picture pic = (new Picture(cursor.getString(group_i),cursor.getLong(time_i), cursor.getString(path_i)));
                            pic.setNote(cursor.getString(note_i));
                            pics.add(pic);
                    }
            }  
            cursor.close();
            return pics;
    }
	/** deleteGroup takes in a string of the group name and uses the database helper to
	 * query the database for matching group names.  The database will delete all entries
	 * (including pictures) associated with that group name.
	 *
	 * @param groupName	String of the group name of the specific blemish
	 */
	public void deleteGroup(String groupName){//delete whole group base on groupname
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.delete(PICTURETABLE, COL_GROUP + "=?", new String[]{groupName});
		db.delete(GROUPTABLE, COL_GROUP + "=?", new String[]{groupName});
	}

	/** deletePicture takes in a picture object and uses the path of the picture to query the 
	 * database for the matching entry.  The database will remove this entry from the table.
	 *
	 * @param pic 		Picture object that is to be deleted from the table
	 */
	public void deletePicture(Picture pic){ //delete picture based on path
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.delete(PICTURETABLE, COL_PATH+"=?", new String[]{pic.getPath()});
	}
	/** addGroup method takes a string input and calls the addValues method to add an entry to 
	 * the table.  The entry has the appropriate group name, 0 for time, and null for path 
	 * (to prevent it from being selected from queries but to allow for the group name to 
	 * exist in the table)
	 *
	 * @param groupName	String of the group name of the specific blemish
	 */
	public void addGroup(String groupName, long reminder){  //add group base on group name. time =0 path= null
		ContentValues values = new ContentValues();
		values.put(COL_GROUP, groupName);
		values.put(COL_REMINDER, reminder);
		
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.insert(GROUPTABLE, null, values);
		
		Log.i("database", "Group added: `" + groupName +"` reminder: " + reminder);
	}

	/** addPicture method takes in a picture object and calls the addValues method on the 
	 * object's group, time of creation, and path.
	 * 
	 * @param pic		Created picture object
	 */
	public void addPicture(Picture pic){ //insert pic base on groupname path and time
		addValues(pic.getGroup(), pic.getTime(), pic.getPath());
	}

	/** addValues method takes in a string, time, and path corresponding to a picture object.  
	 * addValues uses each of these values to fill the appropriate columns for the new entry.
	 * The values are first inserted into a ContentValues object and added to the table with 
	 * the db.insert call.
	 *
	 * @param name		Taken from the picture object: string name of the blemish group
	 * @param time		Taken from the picture object: long time of creation
	 * @param path		Taken from the picture object: string path to the image in memory
	 */
	private void addValues(String name, long time, String path){
		ContentValues values = new ContentValues();
		values.put(COL_GROUP,name);
		values.put(COL_PATH,path);
		values.put(COL_TIME,time);

		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.insert(PICTURETABLE, null, values);
	}

	/** groupExists takes in a string of the group name and returns a boolean value indicating 
	 * whether the group name exists in the table or not.
	 *
	 * @param groupName	String representing the name of the blemish group
	 *
	 * @return true	Returns true if the group exists in the table.  False otherwise
	 */

	public boolean groupExists(String groupName){


		Cursor cursor= db.query(true,GROUPTABLE, new String[]{COL_GROUP}, COL_GROUP+"=?", new String[]{groupName}, null, null,null, null);

		if(cursor.getCount()==0)
			return false;  
		else
			return true; //true means have already exists


	}
	/** pictureExists takes in a picture and returns a boolean value indicating 
	 * whether the picture exists in the table or not.
	 *
	 * @param pic		Picture object
	 *
	 * @return true	Returns true if the picture exists in the table.  False otherwise
	 */
	public boolean pictureExists(Picture pic){
		Cursor cursor=db.query(PICTURETABLE, new String[]{COL_PATH}, COL_PATH+"=?", new String[]{pic.getPath()}, null, null, null);
		if(cursor == null)
			return false;
		else
			return true;
	}
	/** Closes the database upon clean exiting.
	 */
	public void close(){
		db.close();
		dbHelper.close();
		

	}


	/** addNote method takes in a path to the picture and a string value of the desired note to add. 
	 * The method uses the path to find a specific photo, and then adds the string note to the NOTE column
	 * 
	 * @param path			path to the specified picture
	 * @param note			String note to accompany the photo
	 */
	public void addNote(String path, String note){
		ContentValues values = new ContentValues();
		values.put(COL_NOTE,note);

		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.update(PICTURETABLE, values, COL_PATH + "='" + path + "'",null);
	}
	


	/** getNotes queries the database for the specified photo using the path parameter.  getNotes will
	 * return the string value of the note stored in the NOTE column of the database.
	 *
	 * @param path		path to the specific photo
	 *
	 * @return note		String value of the note associated with the photo
	 */
	public String getNotes(String path){
		String note = null;
		Cursor cursor= db.query(PICTURETABLE, new String[]{COL_NOTE}, COL_PATH+"=?", new String[]{path}, null, null, null);
		while(cursor.moveToNext()){
			note = cursor.getString(cursor.getColumnIndex(COL_NOTE));
		} 
		cursor.close();
		return note;
	}

	/** getPicCount queries the database for the specified group and returns a long of the number of 
	 *  pictures in that group
	 * 
	 * @param group
	 * @return s.simpleQueryForLong() ; A long value
	 */
	
	public long getPicCount(String group){
		SQLiteStatement s = db.compileStatement("select count(*) from " + 
				PICTURETABLE + " where " + COL_GROUP + "='" + group +"'");
		
		return s.simpleQueryForLong();
	}
	
	/** setReminder takes in a string value of the group name and a long value of the reminder time. setReminder
	 * will add the desired long time to the reminder database table.
	 * 
	 * @param group			String value of the group name
	 * @param time			long value of the reminder time in milliseconds
	 */
	
	public void setReminder(String group, long time){
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		Cursor cursor=db.rawQuery("SELECT * FROM " + GROUPTABLE + " WHERE " + COL_GROUP + " =?", new String[]{group});
		ContentValues values = new ContentValues();

		// could also try if cursor != null
		if (cursor.moveToFirst()){
			values.put(COL_REMINDER,time);
			db.update(GROUPTABLE, values, COL_GROUP + "='" + group + "'",null);
		}
		else{
			addGroup(group, time);
		}
		cursor.close();
	}
	
	/** getReminder takes in a string value of the group name and returns a long value of the reminder time in milliseconds
	 * 
	 * @param group		 String value of the group name
	 * @return long      value of the reminder in milliseconds
	 */
	public long getReminder(String group){
		Cursor cursor = db.rawQuery("SELECT " + COL_REMINDER + " FROM " + GROUPTABLE + " WHERE " + COL_GROUP +" = '" + group +"'", null);
		
		if(cursor.moveToFirst()){	// Should check if cursor is null?
			Log.i("database", "returning reminder for group: " + group);
			return cursor.getLong(cursor.getColumnIndex(COL_REMINDER));
		}
		else{
			Log.i("database", "no group: " + group);
			return -1;
		}
	}
	/** getMostRecent takes in a string value of the group name and returns the long value of the time the most recent picture was taken.
	 * It uses a database query to get all the pictures in the group, and uses the getTime function to return the milliseconds long time
	 * that the last picture in the list (most recent) was taken
	 * 
	 * @param group				string value of the group name
	 * @return	pictime			long value of the millisecond time of the most recent picture
	 */
	public long getMostRecent(String group) {
		//returns long value of the time that the most recent (largest #) photo was taken
		ArrayList<Picture> pics = getPictures(group);
		if (!pics.isEmpty()){
		long pictime = pics.get((pics.size()-1)).getTime();
		Log.i("picturetime", Long.toString(pictime));
		return pictime;
		} else {
			return 0;
		}
	}
	

}
