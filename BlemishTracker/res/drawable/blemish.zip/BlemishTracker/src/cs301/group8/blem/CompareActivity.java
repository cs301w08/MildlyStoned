package cs301.group8.blem;

import java.sql.Date;
import java.text.DateFormat;
import java.util.ArrayList;


import cs301.group8.database.AppDatabase;
import cs301.group8.meta.Picture;
import cs301.group8.meta.Util;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/** CompareActivity class is an Android activity class that allows the user to view two blemishes at a time, side by side, 
 * for comparative reasons.  The activity allows the user to cycle through the pictures of the blemish group and long click
 * the top image to set it to the bottom image view.
 *
 * @author Group 08 <cs301-group8@ualberta.ca>
 * @version 1.0
 */

public class CompareActivity extends Activity{

	private AppDatabase db;
	private ArrayList<Picture> pics;
	private int current;
	  public static final String PREFS_TOOL = "MyPrefsTOOL";
	private int constant;
	public boolean tool;
	private boolean left_hidden=false;
	private boolean right_hidden=false;
	/** onCreate recalls the PictureDatabase and gets the pictures based on the group name (pulled from the intent extras).
	 *  onCreate initializes both image views to be the the selected picture initially.  onCreate also sets listeners for 
	 *  arrow buttons to scroll through the top image, and on the image itself so that the user can click an image and be 
	 *  taken to the ImageActivity activity.
	 *  
	 *  @param savedInstanceState		Bundle of information regarding the state of the activity from previous loads
	 * 
	 */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.compare_activity);
		Intent intent = getIntent();
		db = new AppDatabase(this);
		pics = db.getPictures(intent.getStringExtra("groupName"));

		current = intent.getIntExtra("position", 0);
		constant = current;
		
		       SharedPreferences settings10 = getSharedPreferences(PREFS_TOOL, 0);        
	               tool = settings10.getBoolean("tool", false);
		
		//if (current == 0){
		//	left_hidden = true;
		//}
		//if (current +1 == pics.size()){
		//	right_hidden = true;
		//}

		findViewById(R.id.compare_next).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (current + 1 < pics.size()){
					current ++;
					setTop();
				}

			}
		});
		findViewById(R.id.compare_prev).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (current > 0){
					current --;
					setTop();
				}
			}
		});

		findViewById(R.id.compare_image_frist).setOnLongClickListener( new OnLongClickListener() {
			public boolean onLongClick(View v) {
				constant = current;
				setBottom();
				return true;
			}
		});
		findViewById(R.id.compare_image_frist).setOnClickListener( new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), ImageActivity.class);
				intent.putExtra("picture", pics.get(current));
				startActivity(intent);
			}
		});
		findViewById(R.id.compare_image_second).setOnClickListener( new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(getApplicationContext(), ImageActivity.class);
				intent.putExtra("picture", pics.get(constant));
				
				startActivity(intent);
			}
		});

		setTop();
		setBottom();
		Toast t = Toast.makeText(getApplicationContext(), "Long click to set bottom image", Toast.LENGTH_SHORT);
		t.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 0);
		if(tool){t.show();}

		android.util.Log.i("PERFORM", "Compare: onCreate");
	}

	/** setTop method is called when the user is cycling through the pictures with the arrow buttons.  setTop
	 * calls the new path of the image based on the relative position of the image.  setTop will set the top 
	 * image to the new scrolled-to image and the title to the (user friendly) time that the picture was taken
	 */
	private void setTop(){
		if (current < pics.size() && current >= 0){
			Picture pic = pics.get(current);
			((TextView) findViewById(R.id.compare_text_first)).setText(Util.timeToDate(pic.getTime()));

			ImageView image = (ImageView) findViewById(R.id.compare_image_frist);
			Bitmap bMap = BitmapFactory.decodeFile(Util.getPath(pic));
			image.setImageBitmap(bMap);
			
			
			
		}
		else{
			System.out.println("Index out of bounds");
			Log.i("error", "Index out of bounds");
		}
		if (current + 1 == pics.size()){
			((ImageView)findViewById(R.id.compare_next)).setImageDrawable(null);
			right_hidden = true;
		}
		
		else if (right_hidden){
			((ImageView)findViewById(R.id.compare_next)).setImageResource(R.drawable.forward_arrow);
			right_hidden = false;
		}
		
		if (current == 0){
			((ImageView)findViewById(R.id.compare_prev)).setImageDrawable(null);
			left_hidden = true;
		}
		else if (left_hidden){
			((ImageView)findViewById(R.id.compare_prev)).setImageResource(R.drawable.back_arrow);
			left_hidden = false;
		}
		
	}

	/** setBottom is called on activity creation and when the user long clicks the top image.  By long clicking the
	 * top image, setBottom will transfer the top image and save it to the bottom image so that the user can continue
	 * scrolling the top image and compare it to the new bottom image. 
	 */
	private void setBottom() {
		if (constant < pics.size() && constant >= 0){
			Picture pic = pics.get(constant);
			((TextView) findViewById(R.id.compare_text_second)).setText(Util.timeToDate(pic.getTime()));

			ImageView image = (ImageView) findViewById(R.id.compare_image_second);
			Bitmap bMap = BitmapFactory.decodeFile(Util.getPath(pic));
			image.setImageBitmap(bMap);
		}
		else{
			System.out.println("Index out of bounds");
			Log.i("error", "Index out of bounds");
		}

	}
}
