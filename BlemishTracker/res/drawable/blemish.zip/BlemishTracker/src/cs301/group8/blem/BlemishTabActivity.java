package cs301.group8.blem;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;


public class BlemishTabActivity extends TabActivity
{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab);
 
     //   Resources res = getResources();
        TabHost tabHost = getTabHost();
        
        Intent intent;
        
        // Tab for groups
        intent = new Intent().setClass(this, MainActivity.class);
        tabHost.addTab(tabHost.newTabSpec("Groups").setIndicator("Groups").setContent(intent));
        
        // Tab for Search
        intent = new Intent().setClass(this, SearchActivity.class);
        tabHost.addTab(tabHost.newTabSpec("Search").setIndicator("Search").setContent(intent));

        // Tab for Settings
        intent = new Intent().setClass(this, SettingsActivity.class);
        tabHost.addTab(tabHost.newTabSpec("Settings").setIndicator("Settings").setContent(intent));
       
        final int tabChildrenCount = tabHost.getTabWidget().getChildCount();
        for (int i = 0; i < tabChildrenCount; i++) {
            tabHost.getTabWidget().getChildAt(i).getLayoutParams().height=40;
           
        }
     // tabHost.getLayoutParams().height = LayoutParams.WRAP_CONTENT;
      //tabHost.requestLayout(); 

    }
}

