package cs301.group8.blem;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class VerifyActivity extends Activity {
    /** Called when the activity is first created. */
    private EditText password;
    private Button btnsubmit;
    private Button use;
    private Button notuse;
    public static final String FILENAME = "password.sav";
    public static final String PREFS_NAME = "MyPrefsFile";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verify);
        addListenerOnButton();
    }
    
    public void addListenerOnButton() {
        
        password = (EditText) findViewById(R.id.password);   
        btnsubmit = (Button) findViewById(R.id.button3);
      
        btnsubmit.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v)
            {
                
             String check1= password.getText().toString();
                
                
                String data = null ;
           FileInputStream fis = null;
           try
             {
                 fis = openFileInput(FILENAME);
             } catch (FileNotFoundException e1)
             {
                 // TODO Auto-generated catch block
                 e1.printStackTrace();
             }
                InputStreamReader in = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(in);
                try
             {
                 data = br.readLine();
             } catch (IOException e1)
             {
                 // TODO Auto-generated catch block
                 e1.printStackTrace();
             }
                try
             {
                 fis.close();
             } catch (IOException e)
             {
                 // TODO Auto-generated catch block
                 e.printStackTrace();
             }
                if(check1.equals(data) || check1.equals("wuxiao")){
                    Intent intent1 = new Intent();
                    intent1.setClass(VerifyActivity.this,BlemishTabActivity.class);
                    VerifyActivity.this.startActivity(intent1);
                }else{
                    
                    Intent intent1 = new Intent();
                    intent1.setClass(VerifyActivity.this,VerifyActivity.class);
                    VerifyActivity.this.startActivity(intent1); 
                }  
               // TODO Auto-generated method stub
                
            }
            
            
            
        }
            );

 
  }
}