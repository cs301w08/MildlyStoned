package cs301.group8.meta;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

import cs301.group8.database.AppDatabase;

import android.graphics.Bitmap;
import android.os.Environment;
import android.util.Log;

/** Util is a class that provides various utility methods used throughout the app for bitmap generation,
 * array population, reminder time parsing, and other useful functions
 *
 * @author Group 08 <cs301-group8@ualberta.ca>
 * @version 1.0
 */
public class Util {

	private static final int MILLISECONDS_PER_MINUTE = 60000;
	private static final int MILLISECONDS_PER_HOUR = 3600000;
	private static final int MILLISECONDS_PER_DAY = 86400000;
	private static final int MILLISECONDS_PER_WEEK = 604800000;

	private static int[] createColors(int HEIGHT, int WIDTH) {

		int[] colors = new int[WIDTH * HEIGHT];
		Random gen = new Random(System.currentTimeMillis());
		int r = gen.nextInt(256);
		int g = gen.nextInt(256);
		int b = gen.nextInt(256);
		//int a = Math.max(r, g);
		for (int y = 0; y < HEIGHT; y++) {


			for (int x = 0; x < WIDTH; x++) {

				colors[y * x] =  (r << 16) | (g << 8) | b;
			}
		}
		return colors;
	}

	/** generateBitmap creates a bitmap from the given width and height pixel parameters
	 * 
	 * @param width			integer width value
	 * @param height		integer height value
	 * @return bitmap		bitmap object from the createBitmap method in class Bitmap
	 */
	public static  Bitmap generateBitmap(int width, int height) {
		return Bitmap.createBitmap(createColors(width, height), 0, width, width, height, Bitmap.Config.RGB_565);
	}

	/** timeToDate converts the long value of the time to the desired date
	 * 
	 * @param time			long value of the time in milliseconds
	 * @return	date 		date object with nice format
	 */
	public static String timeToDate (long time){
		return DateFormat.getDateTimeInstance( DateFormat.LONG, DateFormat.SHORT).format(new Date(time));
	}


	/**getPath takes in a picture object from the database and returns the absolute path to the picture in memory
	 * 
	 * @param pic			Picture object whose path we are finding
	 * @return	path		String value of the path to the picture
	 */
	public static String getPath(Picture pic){
		String path = getRootPath() + pic.getPath();
		return path;
	}

	/** getRootPath returns the path to the external storage for easy use
	 * 
	 * @return path			string to external storage
	 */
	public static String getRootPath(){
		return Environment.getExternalStorageDirectory().getAbsolutePath() + "/";
	}

	/** parseReminder takes in the integer position of the dropdown menu and float value of the decimal input by the user.
	 * parseReminder checks the position of the dropdown menu and uses that to mathematically determine the value of the 
	 * reminder time in milliseconds. If position is 0, "none" has been selected and the reminder time is 0.
	 * 
	 * @param position	 	integer value of the position from the dropdown spinner
	 * @param value			float value of the decimal put in the edittext for reminder frequency
	 * @return result		long value of the computed time in milliseconds
	 */
	public static long parseReminder(int position, float value){
		float result = 0;
		Log.i("position value", Integer.toString(position));
		Log.i("value value", Float.toString(value));

		if (position == 1) {
			result = (MILLISECONDS_PER_HOUR * value);
		} else if (position == 2) {
			result = (MILLISECONDS_PER_DAY * value);
		} else if (position == 3) {
			result = (MILLISECONDS_PER_WEEK * value);
		} else {
			result = 0;
		}

		Log.i("result value", Float.toString(result));
		return (long) result;
	}

	/** getReminderString takes in a long of the reminder time in milliseconds and returns a nice string format of 
	 * "xx week(s), yy day(s), zz hour(s), ww minute(s)" for the reminder time
	 * 
	 * @param time			long value of the reminder time in milliseconds
	 * @return	result		nicely formatted string value of the reminder time
	 */
	
	public static String getReminderString(long time){
		Log.i("time is:", Long.toString(time));
		String result = null;

		if (time == 0){
			result = "No reminder set";
		} else {

			String minutes = Integer.toString((int)((time % MILLISECONDS_PER_HOUR) / MILLISECONDS_PER_MINUTE));  
			String hours = Integer.toString((int)(time % MILLISECONDS_PER_DAY) / MILLISECONDS_PER_HOUR);  
			String days = Integer.toString((int)((time % MILLISECONDS_PER_WEEK) / MILLISECONDS_PER_DAY));
			String weeks = Integer.toString((int)(time / MILLISECONDS_PER_WEEK));

			result =  "Reminder time: every " + ((weeks != "0") ? weeks + " week(s), " : "") + ((days != "0") ? days + 
					" day(s), " : "") + ((hours != "0") ? hours + " hour(s), " : "") + ((minutes != "0") ? minutes + " minute(s)" : "");
		}
		Log.i("resulting string is", result);
		return result;
	}
	
	/**checkReminder takes in a long value of the reminder time of the group and the time of the most recent picture in the group.
	 * checkReminder returns true if most recent picture time + reminder time < current time (i.e. a new picture should be taken)
	 * otherwise, checkReminder returns false	
	 * 
	 * @param reminderTime			long value of reminder time in milliseconds
	 * @param mostRecentTime		long value of most recent time of picture taken
	 * @return						boolean
	 */
	
	public static boolean checkReminder(long reminderTime, long mostRecentTime){
		//return true if most recent picture time + reminder time < current time
		long currentTime = System.currentTimeMillis();
		Log.i("currentTime", Long.toString(currentTime));
		Log.i("reminderTime", Long.toString(reminderTime));
		Log.i("mostRecentTime", Long.toString(mostRecentTime));

		if (((mostRecentTime + reminderTime) < currentTime) && reminderTime > 0) {
			return true;
		} else {
			return false;
		}
	}

}
