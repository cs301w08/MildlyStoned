package cs301.group8.blem;

import java.io.File;
import java.util.ArrayList;

import cs301.group8.database.AppDatabase;
import cs301.group8.meta.Picture;
import cs301.group8.meta.Util;

import android.app.Dialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ImageView;

/** BlemishActivity is an Android activity that displays the list of existing photos for a specific type of blemish.
 * BlemishActivity is launched when the user selects a blemish group from the main menu.
 * BlemishActivity also establishes buttons that allow the user to take pictures or delete them from memory.
 *
 * @author Group 08 <cs301-group8@ualberta.ca>
 * @version 1.0
 */

public class BlemishActivity extends ListActivity{

	private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 100;
	private Uri imageUri;
	private AppDatabase db;
	public boolean tool;
	private CustomAdapter listAdpt;
	protected ArrayList<Picture> pics;
	private String blemishGroup;
	    public static final String PREFS_TOOL = "MyPrefsTOOL";
	private Picture pic = null;
	private int position;

	/** onCreate establishes the clickable ListView of blemishes and the Add Blemish button.
	 * onCreate populates the list using the getPictures database call
	 * 
	 * @param savedInstanceState		Bundle of information of the saved state from previous loads
	 */
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.picture_list);
		db = new AppDatabase(this);

		findViewById(R.id.add_blemish).setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				takeAPhoto();
			}
		});
		 SharedPreferences settings10 = getSharedPreferences(PREFS_TOOL, 0);        
                 tool = settings10.getBoolean("tool", false);

		((Button)this.findViewById(R.id.add_blemish)).setText("Take a Photo");

		blemishGroup = this.getIntent().getStringExtra("groupName");
		pics = db.getPictures(blemishGroup);
		
		((TextView) this.findViewById(R.id.BlemishViewTitle)).setText(blemishGroup);
		
		String reminderString = Util.getReminderString(db.getReminder(blemishGroup));
		((TextView) this.findViewById(R.id.ReminderViewTitle)).setText(reminderString);
		


		this.listAdpt = new CustomAdapter(this, R.layout.group_item);
		this.getListView().setAdapter(listAdpt);  

		Toast t = Toast.makeText(getApplicationContext(), "Long click to compare images", Toast.LENGTH_SHORT);
		t.setGravity(Gravity.BOTTOM|Gravity.CENTER, 0, 85);
		if(tool){t.show();}
		android.util.Log.i("PERFORM", "Blemish: onCreate");
	}

	protected void onStart(){
		android.util.Log.i("PERFORM", "Blemish: onStart");
		super.onStart();
		db = new AppDatabase(this);
	}
	protected void onStop(){
		android.util.Log.i("PERFORM", "Blemish: onStop");
		super.onStop();
		db.close();
	}
	@Override
	protected void onResume (){
		android.util.Log.i("PERFORM", "Blemish: onResume");
		update();
		super.onResume();
	}

	private void update(){
		android.util.Log.i("PERFORM", "Blemish: update");
		// Make sure the list adapter has been set and then add the pictures to it
		if (listAdpt != null){		
			pics = db.getPictures(blemishGroup);
			listAdpt.clear();
			for (int i=0;i<pics.size();i++){
				listAdpt.add(pics.get(i));
				android.util.Log.i("VERRIFY", "Added to ListAdpt " + i);
			}
		}
		// Notify to update GUI
		listAdpt.notifyDataSetChanged();

	}

	/** onCreateDialog calls the make dialog method in the Dialogs class for the delete item dialog.  It sets the
	 *  appropriate deleting onClick method which is executed upon a user click.  The method deletes the selected file from 
	 *  memory upon the user pressing "Yes" and removes the entry from the database.  Finally, the method will refresh the 
	 *  list after deletion.
	 *  
	 *  @param which	integer corresponding to which dialog ID is being initiated
	 */
	@Override
	protected Dialog onCreateDialog(int which){
		Dialog dialog = null;
		final int pos = position;
		switch (which) {
		case Dialogs.DIALOG_DELETE_ITEM:
			dialog = Dialogs.makeDeleteDialog(this, new DialogInterface.OnClickListener() {
				// Set yes listener
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Picture pic = pics.get(pos);
					new File(Util.getPath(pic)).delete();
					db.deletePicture(pic);
					removeDialog(Dialogs.DIALOG_DELETE_ITEM);
					update();
				}
			}, new DialogInterface.OnClickListener() {
				// Set no listener
				@Override
				public void onClick(DialogInterface dialog, int which) {
					removeDialog(Dialogs.DIALOG_DELETE_ITEM);
				}
			});
			break;

		default:
			break;
		}
		return dialog;
	}

	/** takeAPhoto is the method that calls the camera through an intent and initiates the picture object.
	 * takeAPhoto uses a system call to get the current time in milliseconds and creates a new picture object 
	 * based on the current group and the current time.  It also creates the Uri object that will be passed to the
	 * camera so that the camera knows to save the image in the appropriate folder.  If the folder (designated by 
	 * group name) does not exist, it will first create it.
	 */
	protected void takeAPhoto(){
		Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		// Create the dir to store images
		String folder = Util.getRootPath();
		File folderF = new File(folder+blemishGroup);

		if (!folderF.exists()) {
			folderF.mkdir();
		}

		// Created picture and pass uri
		this.pic = new Picture(blemishGroup, System.currentTimeMillis());

		Log.i("take", pic.getPath());

		File imageFile = new File(Util.getPath(pic));
		imageUri = Uri.fromFile(imageFile);
		intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

		startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
	}




	/** onActivityResult is called upon the return of the camera call.  It checks that the results of the camera
	 * are appropriate and then creates a toast to inform the user that the picture was taken correctly.  Finally,
	 * onActivityResult adds the picture object to the database through the addPicture() method.
	 * 
	 * @param requestCode		integer request code returned from the camera.  Should be 100
	 * @param resultCode		integer result code returned from the camera.  Should be RESULT_OK
	 * @param intent			caller intent
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent intent){
		//check request code, check result code, show image on image button
		if (requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE){
			if (resultCode == RESULT_OK){

				if(tool){Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_LONG).show();}
				db.addPicture(pic);
			//	update();
			} 
		}
		// After the pic has been added set it back to null
		pic = null;

	}
	private class CustomAdapter extends ArrayAdapter<Picture>{

		public CustomAdapter (Context context, int res_id){

			super (context, res_id, pics);

		}

		/** getView is called for each element in the list.  It allows for us to place a button (the X delete button) inside
		 * each ListView item based on the layout file.  Returns row, the custom view used to populate the ListView
		 *
		 * @param position		position of the element in the ListView
		 * @param convertView		
		 * @param parent		parent viewgroup that is passed to the inflater
		 *
		 * @return v			v is the custom view used to populate the ListView in the BlemishActivity
		 */
		@Override
		public View getView(final int position, View convertView, ViewGroup parent){

			if (pics == null)
				return null;

			View v = convertView;

			if (v==null){
				LayoutInflater inflater=getLayoutInflater();
				v=inflater.inflate(R.layout.blemish_item, null);

			}
			
			// Set the thumbnail
			final Picture pic = pics.get(position);
            imageUri = Uri.fromFile(new File(Util.getPath(pic)));
           
            ((ImageView) v.findViewById(R.id.littleimage)).setImageDrawable(Drawable.createFromPath(imageUri.getPath()));
			
			((Button) v.findViewById(R.id.blemish_remove_button)).setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					// Set listener for delete button [x]
					try{
						BlemishActivity.this.position = position;
						showDialog(Dialogs.DIALOG_DELETE_ITEM);
					}catch (Exception e){
						Log.i("error", "Unable to delete " + Util.getPath(pic));
					}

				}
			});
			// Set listener for each row (v)
			v.setOnLongClickListener(new OnLongClickListener() {
				/** onLongClick is called when the user selects a picture from the blemishes list with a long click.  
				 * onLongClick initiates the intent to transfer to the CompareActivity activity.  It starts the 
				 * intent with position and group name as extra information
				 *
				 * @param v			The view element of the list
				 * 
				 * @return true		Returns a boolean true value
				 */
				public boolean onLongClick(View v) {
					Intent intent = new Intent(getApplicationContext(), CompareActivity.class);
					intent.putExtra("position", (position)); 
					intent.putExtra("groupName", (blemishGroup)); 
					startActivity(intent);
					return true;
				}
			});

			v.setOnClickListener(new OnClickListener() {
				/** onClick is called when the user selects a picture from the blemishes list with a click.  
				 * onClick initiates the intent to transfer to the ImageActivity activity.  It starts the 
				 * intent with the path, group, and date as extra information
				 *
				 * @param v			The view element of the list
				 * 
				 * @return v		The view element of the list
				 */
				public void onClick(View v) {
					Intent intent = new Intent(getApplicationContext(), ImageActivity.class);
					intent.putExtra("picture", pic);
					startActivity(intent);
				}
			});
			
			// Set the 'descriptive' text
			TextView label=(TextView)v.findViewById(R.id.title_text);
			label.setText(Util.timeToDate(pic.getTime()));


			return v;
		}
	} 
}   
