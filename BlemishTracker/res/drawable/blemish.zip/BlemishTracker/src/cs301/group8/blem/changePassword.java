package cs301.group8.blem;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class changePassword extends Activity {
    /** Called when the activity is first created. */
    private EditText password;
    private EditText passwordshang;
    private Button btnsubmit;

    public static final String FILENAME="password.sav";
    public static final String PREFS_NAME = "MyPrefsFile";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changepass);
        addListenerOnButton();
    }
    
    public void addListenerOnButton() {
        
        password = (EditText) findViewById(R.id.password);   
        btnsubmit = (Button) findViewById(R.id.button3);
        passwordshang=(EditText) findViewById(R.id.EditText01);   
        btnsubmit.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v)
            {
       
                String string = password.getText().toString();
                String string1 = passwordshang.getText().toString();
                if(string1.equals(string)){
                FileOutputStream fos = null;
                try
                {
                    fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
                } catch (FileNotFoundException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                try
                {
                    fos.write(string.getBytes());
                } catch (IOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                try
                {
                    fos.close();
                } catch (IOException e)
                {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                Intent intent2 = new Intent();
                intent2.setClass(changePassword.this,BlemishTabActivity.class);
                changePassword.this.startActivity(intent2);
                    
                }else{
                Context context = getApplicationContext();
                CharSequence text = "Two passwords not equal";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                
            }
            }
            
            
        }
            );

 
  }
}