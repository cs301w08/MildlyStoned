package cs301.group8.blem;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;


public class SettingsActivity extends Activity
{
    private CheckBox usepassword;
    private CheckBox tooltip;
    private Button change;
    private Button use;
    public static final String FILENAME = "password.sav";
    private Button notuse;
    public static final String PREFS_NAME = "MyPrefsFile";
    public static final String PREFS_TOOL = "MyPrefsTOOL";
  
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.systemsettings);
        
        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.planets_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        boolean first = settings.getBoolean("first", false);
        
        SharedPreferences settings10 = getSharedPreferences(PREFS_TOOL, 0);        
        boolean tool = settings10.getBoolean("tool", false);
        tooltip=(CheckBox)findViewById(R.id.tooltip);
        if(tool){
        tooltip.setChecked(true);
        }
        
        usepassword= (CheckBox) findViewById(R.id.checkBox1);
        if (first){
            System.out.println("dianliang");
            usepassword.setChecked(true);
        }
        addListenerOnButton();
    }
    
    public void addListenerOnButton() {


        change = (Button) findViewById(R.id.button3);
        tooltip.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                if (((CheckBox) v).isChecked()) {
                    SharedPreferences settings10 = getSharedPreferences(PREFS_TOOL, 0);
                    SharedPreferences.Editor editor = settings10.edit();
                    editor.putBoolean("tool",true);
                    editor.commit();
                  
                 
                }else{
                    SharedPreferences settings10 = getSharedPreferences(PREFS_TOOL, 0);
                    SharedPreferences.Editor editor = settings10.edit();
                    editor.putBoolean("tool",false);
                    editor.commit();
                }
   
            }
          });
        usepassword.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                

                  //is chkIos checked?
               
                  if (((CheckBox) v).isChecked()) {
                      SharedPreferences settings1 = getSharedPreferences(PREFS_NAME, 0);
                      SharedPreferences.Editor editor = settings1.edit();
                      editor.putBoolean("first",true);
                      editor.commit();
                      {

                          String data = null ;
                  
                          FileInputStream fis = null;
                       try
                       {
                           fis = openFileInput(FILENAME);
                       } catch (FileNotFoundException e1)
                       {
                           // TODO Auto-generated catch block
                           e1.printStackTrace();
                       }
                          InputStreamReader in = new InputStreamReader(fis);
                          BufferedReader br = new BufferedReader(in);
                          try
                       {
                           data = br.readLine();
                       } catch (IOException e1)
                       {
                           // TODO Auto-generated catch block
                           e1.printStackTrace();
                       }
                          try
                       {
                           fis.close();
                       } catch (IOException e)
                       {
                           // TODO Auto-generated catch block
                           e.printStackTrace();
                       }
                        if(data==null){
                            Intent intent2 = new Intent();
                            intent2.setClass(SettingsActivity.this,changePassword.class);
                            SettingsActivity.this.startActivity(intent2);
                        }
                          
                      }
                   
                  }else{
                      SharedPreferences settings1 = getSharedPreferences(PREFS_NAME, 0);
                      SharedPreferences.Editor editor = settings1.edit();
                      editor.putBoolean("first",false);
                      editor.commit();
                  }
   
            }
          });

        change.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v)
            {
                Intent intent2 = new Intent();
                intent2.setClass(SettingsActivity.this,changePassword.class);
                SettingsActivity.this.startActivity(intent2);
            }
            
            
            
        }
            );
       
 
  }

}
