package cs301.group8.blem;

import java.io.File;
import java.text.DateFormat;

import cs301.group8.database.AppDatabase;
import cs301.group8.meta.Picture;
import cs301.group8.meta.Util;


import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

/** ImageActivity class is an Android activity that displays the selected image from the CompareActivity ImageView or
 * from the BlemishActivity ListView.  It also displays appropriate meta-data regarding the selected photo.
 * Finally, the ImageActivity activity has an EditText view that allows the user to input string notes associated with the photo.
 * When the user clicks on the image, the activity is finished and the application returns to the previous activity.
 *
 * @author Group 08 <cs301-group8@ualberta.ca>
 * @version 1.0
 */

public class ImageActivity extends Activity{
	private Uri imageUri;
	private Picture pic;
	private AppDatabase db;

	/** onCreate is called when the activity is initiated.  onCreate pulls the image path, group, and date from the intent 
	 * extras and  sets the title of the image to the path to the image.  onCreate sets the fullscreen ImageView object to the 
	 * image based on the path it receives.  onCreate also sets TextViews to display appropriate meta-data of the photo.
	 * Finally, onCreate sets the listener that allows the user to click the image and return to the previous activity
	 * 
	 * @param savedInstanceState 		Bundle of information of the saved state from previous loads
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.imageactivity);

		Bundle bundle = getIntent().getExtras();
		pic = bundle.getParcelable("picture");


		
		File imageFile = new File(Util.getPath(pic));
		if (pic != null) {
			TextView textView = (TextView) findViewById(R.id.imagePath);
			textView.setText(pic.getPath());

			((TextView) findViewById(R.id.image_group)).setText(pic.getGroup());
			((TextView) findViewById(R.id.image_date)).setText(Util.timeToDate(pic.getTime()));
		}

		Log.i("PATH", "open: " +imageFile.getAbsolutePath().toString());
		imageUri = Uri.fromFile(imageFile);

		ImageView blemishImage = (ImageView) findViewById(R.id.BlemishPic);
		blemishImage.setImageDrawable(Drawable.createFromPath(imageUri.getPath()));

		blemishImage.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				//click on the image = go back to previous activity
				setNote();
				finish();
			}
		});

		android.util.Log.i("PERFORM", "Image: onCreate");

	}
	/** Upon resuming the activity, the EditText field is set with any text string that 
	 * the user has previously entered which has been saved in the database. 
	 */
	public void onResume(){
		android.util.Log.i("PERFORM", "Image: onResume");
		super.onResume();
		db = new AppDatabase(this);

		EditText field = ((EditText) findViewById(R.id.image_note));
		if(field != null){
			field.setText(pic.getNote());
			//Log.i
		}
		else{
			Log.i("error", "SOMETHING IS NULLLLLL");
		}
	}
	/** Upon pausing the activity, any input text in the EditText field is loaded into the database
	 * through the addNote call.
	 */
	public void onPause(){
		android.util.Log.i("PERFORM", "Image: onPause");
		super.onPause();
		setNote();

		db.close();
	}

	private void setNote(){
		EditText field = ((EditText) findViewById(R.id.image_note));
		if(field != null && field.getText() != null){
			String current = field.getText().toString();
			if (pic.getNote()==null || !current.equals(pic.getNote())){
				pic.setNote(current);
				db.addNote(pic.getPath(), pic.getNote());
				Log.i("error", "added to database: " + current);
			}
			else {
				Log.i("error", "not adding");
			}
		}
	}
}
